import React, { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { motion } from 'motion/react';
import HomePage from './components/pages/HomePage';
import AboutPage from './components/pages/AboutPage';
import ProjectsPage from './components/pages/ProjectsPage';
import ResumePage from './components/pages/ResumePage';
import BlogPage from './components/pages/BlogPage';
import ContactPage from './components/pages/ContactPage';
import ThemeToggle from './components/ThemeToggle';
import CustomCursor from './components/CustomCursor';
import MagneticButton from './components/MagneticButton';
import ScrollVelocityText from './components/ScrollVelocityText';
import logoImage from 'figma:asset/f8e0d4fdfa99f0810ed0358a13ee96e447e08bcc.png';

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    // Smooth scroll setup
    document.documentElement.style.scrollBehavior = 'smooth';

    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      
      // Detect active section based on scroll position
      const sections = ['home', 'about', 'projects', 'resume', 'blog', 'contact'];
      const scrollPosition = window.scrollY + window.innerHeight / 2;
      
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { name: 'Home', id: 'home' },
    { name: 'About', id: 'about' },
    { name: 'Projects', id: 'projects' },
    { name: 'Resume', id: 'resume' },
    { name: 'Blog', id: 'blog' },
    { name: 'Contact', id: 'contact' },
  ];

  return (
    <div className="relative bg-[#FDF5E7] dark:bg-[#1A1715]">
      {/* Custom Cursor */}
      <CustomCursor />

      {/* Fixed Navigation - ALWAYS ON TOP */}
      <nav
        className={`fixed top-0 left-0 right-0 w-full z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-[#FDF5E7]/95 dark:bg-[#1A1715]/95 backdrop-blur-sm shadow-lg border-b-4 border-[#A47A2D]'
            : 'bg-[#FDF5E7]/80 dark:bg-[#1A1715]/80 backdrop-blur-sm border-b-4 border-[#A47A2D]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-12">
          <div className="flex items-center justify-between h-20 sm:h-24">
            {/* Logo with Magnetic Effect */}
            <MagneticButton
              onClick={() => scrollToSection('home')}
              className="flex items-center transition-transform hover:scale-105 bg-transparent border-none"
            >
              <img 
                src={logoImage} 
                alt="Josh Logo" 
                className="h-14 w-14 sm:h-16 sm:w-16 md:h-20 md:w-20"
              />
            </MagneticButton>

            {/* Desktop Navigation with Magnetic Buttons */}
            <div className="hidden md:flex items-center gap-2">
              {navLinks.map((link) => (
                <MagneticButton
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  style={{ fontFamily: 'Michroma, sans-serif' }}
                  className={`px-6 py-3 text-[18px] font-black uppercase transition-all rounded-full border-none ${
                    activeSection === link.id
                      ? 'bg-[#A47A2D] dark:bg-[#A47A2D] text-white dark:text-[#1A1715]'
                      : 'bg-transparent text-[#521D07] dark:text-[#E2E8F0] hover:bg-[#A47A2D]/20 hover:text-[#FFA51F]'
                  }`}
                >
                  {link.name}
                </MagneticButton>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-3 rounded-[16px] bg-[#A47A2D] dark:bg-[#A47A2D] text-white dark:text-[#1A1715] z-50"
            >
              {mobileMenuOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="absolute top-20 sm:top-24 right-0 bottom-0 w-[85vw] max-w-sm bg-[#FDF5E7] dark:bg-[#1A1715] border-l-4 border-[#A47A2D] shadow-2xl overflow-y-auto">
            <div className="px-4 sm:px-6 py-8 space-y-3">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  style={{ fontFamily: 'Michroma, sans-serif' }}
                  className={`block w-full text-left px-6 py-3 text-[18px] sm:text-[20px] font-black uppercase rounded-[20px] transition-all ${
                    activeSection === link.id
                      ? 'bg-[#A47A2D] dark:bg-[#A47A2D] text-white dark:text-[#1A1715]'
                      : 'text-[#521D07] dark:text-[#E2E8F0] hover:bg-[#A47A2D]/20 hover:text-[#FFA51F]'
                  }`}
                >
                  {link.name}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Theme Toggle */}
      <ThemeToggle />

      {/* STANDARD VERTICAL LAYOUT - SMOOTH SCROLLING */}
      
      {/* 1. HERO SECTION */}
      <section 
        id="home" 
        className="relative w-full min-h-screen py-20 bg-[#FDF5E7] dark:bg-[#1A1715]"
      >
        <HomePage />
      </section>

      {/* 2. ABOUT SECTION */}
      <section 
        id="about" 
        className="relative w-full min-h-screen py-20 bg-[#FDF5E7] dark:bg-[#1A1715]"
      >
        <AboutPage />
      </section>

      {/* SCROLL VELOCITY PARALLAX STRIP */}
      <ScrollVelocityText text="BACKEND • FRONTEND • SCALABLE • SECURE" baseVelocity={1} />

      {/* 3. PROJECTS SECTION */}
      <section 
        id="projects" 
        className="relative w-full min-h-screen py-20 bg-[#FDF5E7] dark:bg-[#1A1715]"
      >
        <ProjectsPage />
      </section>

      {/* 4. RESUME SECTION */}
      <section 
        id="resume" 
        className="relative w-full min-h-screen bg-[#FDF5E7] dark:bg-[#1A1715]"
      >
        <ResumePage />
      </section>

      {/* 5. BLOG SECTION */}
      <section 
        id="blog" 
        className="relative w-full min-h-screen py-20 bg-[#FDF5E7] dark:bg-[#1A1715]"
      >
        <BlogPage />
      </section>

      {/* 6. CONTACT SECTION */}
      <section 
        id="contact" 
        className="relative w-full min-h-screen py-20 bg-[#FDF5E7] dark:bg-[#1A1715]"
      >
        <ContactPage />
      </section>
    </div>
  );
}