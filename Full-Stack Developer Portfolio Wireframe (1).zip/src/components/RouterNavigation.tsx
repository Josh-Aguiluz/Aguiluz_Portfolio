import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import logoImage from 'figma:asset/f8e0d4fdfa99f0810ed0358a13ee96e447e08bcc.png';

export default function RouterNavigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Projects', path: '/projects' },
    { name: 'Resume', path: '/resume' },
    { name: 'Contact', path: '/contact' },
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? 'bg-white/95 dark:bg-[#1A1715]/95 backdrop-blur-sm shadow-lg border-b-4 border-[#A47A2D] dark:border-[#A47A2D]'
            : 'bg-[#FDF5E7]/80 dark:bg-[#1A1715]/80 backdrop-blur-sm border-b-4 border-[#A47A2D] dark:border-[#A47A2D]'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-12">
          <div className="flex items-center justify-between h-24">
            {/* Logo */}
            <Link to="/" className="flex items-center transition-transform hover:scale-105">
              <img 
                src={logoImage} 
                alt="Josh Logo" 
                className="h-20 w-20"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-2">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  style={{ fontFamily: 'Michroma, sans-serif' }}
                  className={`px-6 py-3 text-[18px] font-black uppercase transition-all rounded-full ${
                    isActive(link.path)
                      ? 'bg-[#A47A2D] dark:bg-[#A47A2D] text-white dark:text-[#1A1715]'
                      : 'text-[#521D07] dark:text-[#E2E8F0] hover:bg-[#A47A2D]/20 hover:text-[#FFA51F] dark:hover:bg-[#A47A2D]/20'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-3 rounded-[16px] bg-[#A47A2D] dark:bg-[#A47A2D] text-white dark:text-[#1A1715]"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? (
                <X className="w-8 h-8" />
              ) : (
                <Menu className="w-8 h-8" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="absolute top-24 left-0 right-0 bg-white dark:bg-[#1A1715] border-b-4 border-[#A47A2D] dark:border-[#A47A2D] shadow-xl">
            <div className="max-w-7xl mx-auto px-6 py-8 space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  style={{ fontFamily: 'Michroma, sans-serif' }}
                  className={`block px-8 py-4 text-[24px] font-black uppercase rounded-[24px] transition-all ${
                    isActive(link.path)
                      ? 'bg-[#A47A2D] dark:bg-[#A47A2D] text-white dark:text-[#1A1715]'
                      : 'text-[#521D07] dark:text-[#E2E8F0] hover:bg-[#A47A2D]/20 hover:text-[#FFA51F] dark:hover:bg-[#A47A2D]/20'
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}